const body = document.querySelector("body"),
      sidebar = body.querySelector(".sidebar"),
      toggle = body.querySelector(".toggle"),
      searchBtn = body.querySelector(".search-box"),
      modeSwitch = body.querySelector(".toggle-switch"),
      modeText = body.querySelector(".mode-text");

      toggle.addEventListener("click", () =>{
        sidebar.classList.toggle("close");
      })

    modeSwitch.addEventListener("click", () =>{
        body.classList.toggle("dark");
      })

      // Array untuk menyimpan data tugas
let tasks = [];

// Fungsi untuk memuat konten dari hasil.html
const loadContent = async () => {
    try {
        const response = await fetch('hasil.html');
        const html = await response.text();
        
        // Memuat HTML ke dalam div #app
        document.getElementById('app').innerHTML = html;
        
        // Memuat CSS secara dinamis (opsional, karena sudah ada link di hasil.html)
        // Namun karena hasil.html sudah memiliki link ke style.css, tidak perlu manual
        
        // Setelah konten dimuat, inisialisasi aplikasi
        initializeApp();
    } catch (error) {
        console.error('Gagal memuat konten:', error);
        document.getElementById('app').innerHTML = '<div style="text-align: center; padding: 50px; color: red;">❌ Gagal memuat aplikasi</div>';
    }
};

// Fungsi untuk menginisialisasi aplikasi setelah konten dimuat
const initializeApp = () => {
    // Mendapatkan referensi elemen DOM menggunakan getElementById
    const taskListElement = document.getElementById('taskList');
    const loadingElement = document.getElementById('loadingMessage');
    const errorElement = document.getElementById('errorMessage');
    const emptyElement = document.getElementById('emptyMessage');
    const taskInput = document.getElementById('taskInput');
    const addButton = document.getElementById('addBtn');

    // Validasi apakah elemen-elemen penting ada
    if (!taskListElement || !loadingElement || !errorElement || !emptyElement || !taskInput || !addButton) {
        console.error('Elemen DOM tidak ditemukan');
        return;
    }

    // Fungsi untuk menampilkan loading
    const showLoading = () => {
        loadingElement.style.display = 'block';
        errorElement.style.display = 'none';
        emptyElement.style.display = 'none';
        taskListElement.innerHTML = '';
    };

    // Fungsi untuk menyembunyikan loading
    const hideLoading = () => {
        loadingElement.style.display = 'none';
    };

    // Fungsi untuk menampilkan error
    const showError = () => {
        errorElement.style.display = 'block';
        loadingElement.style.display = 'none';
        emptyElement.style.display = 'none';
        taskListElement.innerHTML = '';
    };

    // Fungsi untuk menampilkan pesan kosong
    const showEmpty = () => {
        if (tasks.length === 0) {
            emptyElement.style.display = 'block';
            taskListElement.innerHTML = '';
        } else {
            emptyElement.style.display = 'none';
        }
    };

    // Fungsi untuk mengamankan HTML (mencegah XSS)
    const escapeHtml = (text) => {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    };

    // Fungsi untuk merender daftar tugas ke halaman menggunakan innerHTML
    const renderTasks = () => {
        if (tasks.length === 0) {
            showEmpty();
            return;
        }

        emptyElement.style.display = 'none';
        
        // Menggunakan innerHTML untuk menampilkan tugas
        let htmlContent = '';
        
        tasks.forEach(task => {
            const statusClass = task.completed ? 'completed' : 'pending';
            const statusText = task.completed ? 'Selesai' : 'Belum';
            const statusBadgeClass = task.completed ? 'completed' : 'pending';
            const titleClass = task.completed ? 'task-title completed' : 'task-title';
            
            htmlContent += `
                <li class="task-item" data-id="${task.id}">
                    <input type="checkbox" class="task-checkbox" ${task.completed ? 'checked' : ''} data-id="${task.id}">
                    <span class="${titleClass}">${escapeHtml(task.title)}</span>
                    <span class="task-status ${statusClass === 'completed' ? 'completed-status' : 'pending-status'}">
                        <span class="status-badge ${statusBadgeClass}"></span>
                        ${statusText}
                    </span>
                </li>
            `;
        });
        
        taskListElement.innerHTML = htmlContent;
        
        // Menambahkan event listener untuk checkbox setelah render
        document.querySelectorAll('.task-checkbox').forEach(checkbox => {
            checkbox.addEventListener('change', (event) => {
                const taskId = parseInt(event.target.getAttribute('data-id'));
                toggleTaskStatus(taskId);
            });
        });
    };

    // Fungsi untuk mengubah status tugas
    const toggleTaskStatus = (taskId) => {
        const task = tasks.find(t => t.id === taskId);
        if (task) {
            task.completed = !task.completed;
            renderTasks(); // Render ulang dengan manipulasi DOM
        }
    };

    // Fungsi untuk mengambil data dari API menggunakan Fetch API dengan async/await
    const fetchTasks = async () => {
        showLoading();
        
        try {
            const response = await fetch('https://jsonplaceholder.typicode.com/todos?_limit=3');
            
            // Cek jika response tidak OK (status bukan 200-299)
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            
            // Memastikan data adalah array
            if (Array.isArray(data)) {
                tasks = data.map(task => ({
                    id: task.id,
                    title: task.title,
                    completed: task.completed
                }));
                renderTasks();
            } else {
                throw new Error('Data yang diterima bukan array');
            }
            
            hideLoading();
        } catch (error) {
            console.error('Error fetching tasks:', error);
            showError();
        }
    };

    // Fungsi untuk menambahkan tugas baru
    const addNewTask = () => {
        // Ambil nilai dari input
        const taskTitle = taskInput.value.trim();
        
        // Validasi input tidak boleh kosong
        if (taskTitle === '') {
            alert('Silakan masukkan tugas terlebih dahulu!');
            return;
        }
        
        // Membuat tugas baru dengan ID unik
        const newTask = {
            id: Date.now(), // Menggunakan timestamp sebagai ID unik
            title: taskTitle,
            completed: false
        };
        
        // Menambahkan ke array tasks
        tasks.push(newTask);
        
        // Membersihkan input
        taskInput.value = '';
        
        // Menampilkan kembali daftar tugas menggunakan manipulasi DOM
        renderTasks();
        
        // Memberikan fokus kembali ke input
        taskInput.focus();
    };

    // Fungsi untuk inisialisasi event listener menggunakan addEventListener
    const initializeEventListeners = () => {
        // Event listener untuk tombol tambah
        addButton.addEventListener('click', addNewTask);
        
        // Event listener untuk menekan Enter di input
        taskInput.addEventListener('keypress', (event) => {
            if (event.key === 'Enter') {
                addNewTask();
            }
        });
    };

    // Fungsi utama untuk memulai aplikasi
    const init = async () => {
        initializeEventListeners();
        await fetchTasks();
    };

    // Menjalankan aplikasi
    init();
};

// Memuat konten saat halaman dimuat
document.addEventListener('DOMContentLoaded', function() {
    // Jika ada div#app, muat konten dari hasil.html
    if (document.getElementById('app')) {
        loadContent();
        return; // Jangan jalankan kode lain untuk halaman ini
    }

    // Kode untuk halaman index.html - menangani form input tugas
    const taskInput = document.getElementById('tugas');
    const addButton = document.getElementById('add-button');

    if (taskInput && addButton) {
        // Fungsi untuk mendapatkan tugas dari localStorage
        const getTasksFromStorage = () => {
            const tasks = localStorage.getItem('indexTasks');
            return tasks ? JSON.parse(tasks) : [];
        };

        // Fungsi untuk menyimpan tugas ke localStorage
        const saveTasksToStorage = (tasks) => {
            localStorage.setItem('indexTasks', JSON.stringify(tasks));
        };

        // Array untuk menyimpan tugas dari index.html
        let indexTasks = getTasksFromStorage();

        // Fungsi untuk menambahkan tugas baru
        const addTask = () => {
            const taskValue = taskInput.value.trim();
            
            if (taskValue === '') {
                alert('Silakan masukkan tugas terlebih dahulu!');
                return;
            }

            // Tambahkan ke array
            const newTask = {
                id: Date.now(),
                title: taskValue,
                completed: false
            };
            
            indexTasks.push(newTask);
            
            // Simpan ke localStorage
            saveTasksToStorage(indexTasks);

            // Tampilkan di console untuk debugging
            console.log('Tugas baru ditambahkan:', taskValue);
            console.log('Daftar tugas:', indexTasks);

            // Kosongkan input
            taskInput.value = '';

            // Alert konfirmasi
            alert(`Tugas "${taskValue}" berhasil ditambahkan!`);
        };

        // Event listener untuk tombol
        addButton.addEventListener('click', addTask);

        // Event listener untuk Enter di input
        taskInput.addEventListener('keypress', function(event) {
            if (event.key === 'Enter') {
                addTask();
            }
        });
    }

    // Kode untuk halaman data-tugas.html - menampilkan daftar tugas
    const taskListElement = document.getElementById('taskList');
    const emptyMessageElement = document.getElementById('emptyMessage');
    const loadingElement = document.getElementById('loadingMessage');
    const errorElement = document.getElementById('errorMessage');
    const apiTaskInput = document.getElementById('taskInput');
    const apiAddButton = document.getElementById('addBtn');

    if (taskListElement && emptyMessageElement && loadingElement && errorElement && apiTaskInput && apiAddButton) {
        let apiTasks = [];

        const showLoading = () => {
            loadingElement.style.display = 'block';
            errorElement.style.display = 'none';
            emptyMessageElement.style.display = 'none';
            taskListElement.innerHTML = '';
        };

        const hideLoading = () => {
            loadingElement.style.display = 'none';
        };

        const showError = () => {
            errorElement.style.display = 'block';
            loadingElement.style.display = 'none';
            emptyMessageElement.style.display = 'none';
            taskListElement.innerHTML = '';
        };

        const showEmpty = () => {
            if (apiTasks.length === 0) {
                emptyMessageElement.style.display = 'block';
                taskListElement.innerHTML = '';
            } else {
                emptyMessageElement.style.display = 'none';
            }
        };

        const renderTasks = () => {
            if (apiTasks.length === 0) {
                showEmpty();
                return;
            }

            emptyMessageElement.style.display = 'none';
            let htmlContent = '';
            apiTasks.forEach(task => {
                const statusClass = task.completed ? 'completed' : 'pending';
                const statusText = task.completed ? 'Selesai' : '';
                const titleClass = task.completed ? 'task-title completed' : 'task-title';

                htmlContent += `
                    <li class="task-item" data-id="${task.id}">
                        <span class="${titleClass}">${task.title}</span>
                        <span class="task-status ${statusClass === 'completed' ? 'completed-status' : 'pending-status'}">
                            <span class="status-badge ${statusClass}"></span>
                            ${statusText}
                        </span>
                    </li>
                `;
            });
            taskListElement.innerHTML = htmlContent;
        };

        const fetchTasks = async () => {
            showLoading();
            try {
                const response = await fetch('https://jsonplaceholder.typicode.com/todos?_limit=3');
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                const data = await response.json();
                apiTasks = data.map(task => ({
                    id: task.id,
                    title: task.title,
                    completed: task.completed
                }));
                hideLoading();
                renderTasks();
            } catch (error) {
                console.error('Fetch error:', error);
                showError();
            }
        };

        const addApiTask = () => {
            const taskTitle = apiTaskInput.value.trim();
            if (taskTitle === '') {
                alert('Silakan masukkan tugas terlebih dahulu');
                return;
            }

            apiTasks.push({
                id: Date.now(),
                title: taskTitle,
                completed: false
            });
            apiTaskInput.value = '';
            renderTasks();
        };

        apiAddButton.addEventListener('click', addApiTask);
        apiTaskInput.addEventListener('keypress', event => {
            if (event.key === 'Enter') {
                addApiTask();
            }
        });

        fetchTasks();
    }
});